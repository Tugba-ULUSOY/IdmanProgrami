
import java.util.Scanner;

/**
 *
 * @author tugba
 */
public class Main 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("İdman Programına Hoşgeldiniz...");
        
        String idmanlar = "Geçerli Hareketler\n"
                         +"Burpee\n"
                         +"Pushup(Şınav)\n"
                         +"Situp(Mekik)\n"
                         +"Squat\n";
        
        System.out.println(idmanlar);
        
        
        System.out.print("Bir idman oluşturun... ");
        
        System.out.print("Burpee sayısı: ");
        int burpee = scanner.nextInt();
        
        System.out.print("Pushup sayısı: ");
        int pushup = scanner.nextInt();
        
        System.out.print("Situp sayısı: ");
        int situp = scanner.nextInt();
        
        System.out.print("Squat sayısı: ");
        int squat = scanner.nextInt();
       
        scanner.nextLine(); // nextInt() den sonra aşağıda nextLine() kullandığımızda hata almamak için
        
        // Idman class ımız içindeki contructor a erişerek; Contructor a parametre olarak yukarıda kullanıcıdan almış olduğumuz değerleri atıyoruz.
        Idman idman = new Idman(burpee, pushup, situp, squat);
        
        System.out.print("İdmanınız Başlıyor...");
        
        while(idman.idmanBittiMi() == false) // İdman bitene kadar döngüyü tekrarla
        {
            System.out.print("Hareket Türü(Burpee, Pushup, Situp, Squat) : ");
            String tur = scanner.nextLine();
            
            System.out.print("Bu hareketten kaç tane yapacaksınız?: ");
            int sayi = scanner.nextInt();
            scanner.nextLine();
            
            idman.hareketYap(tur, sayi);
        }
        
    }
    
}
